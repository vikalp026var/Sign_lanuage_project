# Sign_lanuage_detection > 2023-12-24 9:15pm
https://universe.roboflow.com/zakir-huassin-college-of-engineering-and-technology/sign_lanuage_detection

Provided by a Roboflow user
License: MIT

